﻿namespace AppVentas.Data.Model
{
    public class Producto
    {
        public int IdProducto { get; set; }
        public string NombreProducto { get; set; }
        public string DescripcionProducto { get; set; }
        public decimal PrecioProducto { get; set; }
        public string FotoProducto{ get; set; }
        public string VideoProducto { get; set; }
        public int CantidadProducto { get; set; }
        public string IdEmpresa { get; set; }

        #nullable enable
        public string? NombreEmpresa { get; set; }
        public string? LogoEmpresa { get; set; }

    }
}
