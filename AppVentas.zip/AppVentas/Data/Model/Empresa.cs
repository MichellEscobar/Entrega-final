﻿namespace AppVentas.Data.Model
{
    public class Empresa
    {
        public string IdEmpresa { get; set; }
        public string NombreEmpresa { get; set; }
        public string NITEmpresa { get; set; }
        public string DireccionEmpresa { get; set; }
        public string DepartamentoEmpresa { get; set; }
        public string CiudadEmpresa { get; set; }
        public string TelefonoEmpresa { get; set; }
        public string EmailEmpresa { get; set; }
        public string LogoEmpresa { get; set; }
        public int VentasEmpresa { get; set; }

    }
}
