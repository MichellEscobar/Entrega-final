﻿namespace AppVentas.Data.Model
{
    public class Departamentos
    {
        public int id { get; set; }
        public string departamento { get; set; }
        public string[] ciudades { get; set; }

    }
}
