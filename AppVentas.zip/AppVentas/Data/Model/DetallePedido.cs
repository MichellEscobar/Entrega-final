﻿namespace AppVentas.Data.Model
{
    public class DetallePedido
    {
        public int IdDetalle { get; set; }
        public string RemitenteDetalle { get; set; }
        public string FechaDetalle { get; set; }
        public string TelefonoDetalle { get; set; }
        public string DireccionDetalle { get; set; }
        public string DepartamentoDetalle { get; set; }
        public string CiudadDetalle { get; set; }
        public string EmailDetalle { get; set; }
        public decimal Total { get; set; }
        public string IdUser { get; set; }
        
    }
}
