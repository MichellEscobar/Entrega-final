﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AppVentas.Data.Model;

namespace AppVentas.Data.Service
{
    public interface IEmpresaService
    {
        Task<bool> EmpresaInsert(Empresa empresa, string email);
        Task<string> UserIdSelect(string email);
        Task<Empresa> EmpresaSelect(string id);
        Task<bool> EmpresaSumarVenta(string id);
        Task<IEnumerable<Empresa>> EmpresaSelectAll();
    }
}