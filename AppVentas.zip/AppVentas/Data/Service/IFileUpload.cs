﻿using BlazorInputFile;
using System.Threading.Tasks;

namespace AppVentas.Data.Service
{
    public interface IFileUpload
    {
        Task UploadAsync(IFileListEntry fileEntry, string dir);
    }
}