﻿using AppVentas.Data.Model;
using System.Threading.Tasks;
using System.Collections.Generic;


namespace AppVentas.Data.Service
{
    public interface IProductoService
    {
        Task<bool> ProductoInsert(Producto producto, string idEmpresa);
        Task<IEnumerable<Producto>> ProductoSelectAll();
        Task<IEnumerable<Producto>> ProductoSelectName(string buscar);
        Task<Producto> ProductoSelectId(int id);
        Task<IEnumerable<Producto>> ProductoSelectAllEmpresa(string idEmpresa);
        Task<bool> ProductoRestarVenta(int id);
        Task<IEnumerable<Producto>> ProductoSelectTienda(string buscar);
    }
}