﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;
using AppVentas.Data.Model;

namespace AppVentas.Data.Service
{
    public class ProductoService : IProductoService
    {
        private readonly SqlConnectionConfiguration _configuration;

        public ProductoService(SqlConnectionConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<bool> ProductoInsert(Producto producto, string idEmpresa)
        {
            using (var conn = new SqlConnection(_configuration.Value))
            {
                var parameters = new DynamicParameters();
                parameters.Add("NombreProducto", producto.NombreProducto, DbType.String);
                parameters.Add("PrecioProducto", producto.PrecioProducto, DbType.Decimal);
                parameters.Add("FotoProducto", producto.FotoProducto, DbType.String);
                parameters.Add("VideoProducto", producto.VideoProducto, DbType.String);
                parameters.Add("DescripcionProducto", producto.DescripcionProducto, DbType.String);
                parameters.Add("CantidadProducto", producto.CantidadProducto, DbType.Int16);

                const string query = @"INSERT INTO Producto (NombreProducto, PrecioProducto, FotoProducto, VideoProducto, DescripcionProducto, CantidadProducto, IdEmpresa) VALUES (@NombreProducto, @PrecioProducto,@FotoProducto, @VideoProducto, @DescripcionProducto,@CantidadProducto, @idEmpresa)";
                await conn.ExecuteAsync(query, new { producto.NombreProducto, producto.PrecioProducto, producto.FotoProducto, producto.VideoProducto, producto.DescripcionProducto, producto.CantidadProducto, idEmpresa }, commandType: CommandType.Text);
            }
            return true;
        }

        public async Task<IEnumerable<Producto>> ProductoSelectAll()
        {
            IEnumerable<Producto> productos;

            using (var conn = new SqlConnection(_configuration.Value))
            {
                const string query = @"SELECT a.*, b.NombreEmpresa, b.LogoEmpresa
                    FROM Producto a, Empresa b
                    WHERE a.IdEmpresa = b.IdEmpresa";

                productos = await conn.QueryAsync<Producto>(query, commandType: CommandType.Text);

            }
            return productos;
        }

        public async Task<IEnumerable<Producto>> ProductoSelectName(string buscar)
        {
            IEnumerable<Producto> productos;
        
            using (var conn = new SqlConnection(_configuration.Value))
            {
                string query = @"SELECT a.*, b.NombreEmpresa, b.LogoEmpresa
                FROM Producto a, Empresa b
                WHERE a.IdEmpresa = b.IdEmpresa 
                AND (a.NombreProducto LIKE '%" + buscar + "%'" +
                "OR b.NombreEmpresa LIKE '%" + buscar + "%'" +
                "OR a.DescripcionProducto LIKE '%" + buscar + "%'" +
                "OR a.PrecioProducto LIKE '%" + buscar + "%' )";

                productos = await conn.QueryAsync<Producto>(query, commandType: CommandType.Text);
            }
            return productos;
        }

        public async Task<IEnumerable<Producto>> ProductoSelectTienda(string buscar)
        {
            IEnumerable<Producto> productos;

            using (var conn = new SqlConnection(_configuration.Value))
            {
                string query = @"SELECT a.*, b.NombreEmpresa, b.LogoEmpresa
                FROM Producto a, Empresa b
                WHERE a.IdEmpresa = b.IdEmpresa 
                AND a.NombreProducto LIKE '%" + buscar + "%'";

                productos = await conn.QueryAsync<Producto>(query, commandType: CommandType.Text);
            }
            return productos;
        }

        public async Task<Producto> ProductoSelectId(int id)
        {
            Producto producto;

            using (var conn = new SqlConnection(_configuration.Value))
            {
                const string query = @"SELECT a.*, b.NombreEmpresa, b.LogoEmpresa
                FROM Producto a, Empresa b
                WHERE a.IdEmpresa = b.IdEmpresa AND a.IdProducto = @id";

                producto = await conn.QueryFirstOrDefaultAsync<Producto>(query, new { id }, commandType: CommandType.Text);
            }
            return producto;
        }

        public async Task<IEnumerable<Producto>> ProductoSelectAllEmpresa(string idEmpresa)
        {
            IEnumerable<Producto> productos;

            using (var conn = new SqlConnection(_configuration.Value))
            {
                const string query = @"SELECT a.*, b.NombreEmpresa, b.LogoEmpresa
                    FROM Producto a, Empresa b
                    WHERE a.IdEmpresa = @idEmpresa AND a.IdEmpresa = b.IdEmpresa";

                productos = await conn.QueryAsync<Producto>(query, new { idEmpresa }, commandType: CommandType.Text);

            }
            return productos;
        }

        public async Task<bool> ProductoRestarVenta(int id)
        {
            using (var conn = new SqlConnection(_configuration.Value))
            {
                var query = @"UPDATE Producto
                            SET CantidadProducto = (SELECT SUM(CantidadProducto-1)
							FROM Producto
                            WHERE IdProducto = @id)
                            WHERE IdProducto = @id";
                await conn.ExecuteAsync(query, new { id = id }, commandType: CommandType.Text);
            }

            return true;
        }

    }
}
