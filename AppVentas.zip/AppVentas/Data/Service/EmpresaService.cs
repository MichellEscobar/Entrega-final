﻿using System.Threading.Tasks;
using System;
using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;
using AppVentas.Data.Model;
using System.Collections.Generic;

namespace AppVentas.Data.Service
{
    public class EmpresaService : IEmpresaService
    {
        private readonly SqlConnectionConfiguration _configuration;

        public EmpresaService(SqlConnectionConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<bool> EmpresaInsert(Empresa empresa, string email)
        {
            string newId = await UserIdSelect(email);
            int ventas = 0;

            using (var conn = new SqlConnection(_configuration.Value))
            {
                var parameters = new DynamicParameters();
                parameters.Add("NombreEmpresa", empresa.NombreEmpresa, DbType.String);
                parameters.Add("EmailEmpresa", empresa.EmailEmpresa, DbType.String);
                parameters.Add("TelefonoEmpresa", empresa.TelefonoEmpresa, DbType.String);
                parameters.Add("DireccionEmpresa", empresa.DireccionEmpresa, DbType.String);
                parameters.Add("DepartamentoEmpresa", empresa.DepartamentoEmpresa, DbType.String);
                parameters.Add("CiudadEmpresa", empresa.CiudadEmpresa, DbType.String);
                parameters.Add("NITEmpresa", empresa.NITEmpresa, DbType.String);
                parameters.Add("LogoEmpresa", empresa.LogoEmpresa, DbType.String);

                const string query = @"INSERT INTO Empresa (IdEmpresa, NombreEmpresa, EmailEmpresa, TelefonoEmpresa, DireccionEmpresa, DepartamentoEmpresa, CiudadEmpresa, NITEmpresa, LogoEmpresa, VentasEmpresa) VALUES (@newId, @NombreEmpresa, @EmailEmpresa,@TelefonoEmpresa, @DireccionEmpresa, @DepartamentoEmpresa,@CiudadEmpresa, @NITEmpresa, @LogoEmpresa, @ventas)";
                await conn.ExecuteAsync(query, new { newId, empresa.NombreEmpresa, empresa.EmailEmpresa, empresa.TelefonoEmpresa, empresa.DireccionEmpresa, empresa.DepartamentoEmpresa, empresa.CiudadEmpresa, empresa.NITEmpresa, empresa.LogoEmpresa, ventas }, commandType: CommandType.Text);
            }
            return true;
        }

        public async Task<string> UserIdSelect(string email)
        {
            string id;

            using (var conn = new SqlConnection(_configuration.Value))
            {
                string query = @"SELECT Id 
                               FROM AspNetUsers 
                               WHERE UserName = @email";
                
                id = await conn.ExecuteScalarAsync<string>(query, new { email = email }, commandType: CommandType.Text);
                
            }
            return id;         
        }

        public async Task<Empresa> EmpresaSelect(string user)
        {
            string id = await UserIdSelect(user);

            using (var conn = new SqlConnection(_configuration.Value))
            {
                var query = @"SELECT *
                            FROM Empresa
                            WHERE IdEmpresa = @id";
                return await conn.QueryFirstOrDefaultAsync<Empresa>(query.ToString(), new { id = id }, commandType: CommandType.Text);
            }
        }

        public async Task<bool> EmpresaSumarVenta(string id)
        {           
            using (var conn = new SqlConnection(_configuration.Value))
            {
                var query = @"UPDATE Empresa
                            SET VentasEmpresa = (SELECT SUM(VentasEmpresa+1)
							FROM Empresa
                            WHERE IdEmpresa = @id)
                            WHERE IdEmpresa = @id";
                await conn.ExecuteAsync(query, new { id = id }, commandType: CommandType.Text);
            }
            
            return true;
        }

        public async Task<IEnumerable<Empresa>> EmpresaSelectAll()
        {
            IEnumerable<Empresa> empresas;

            using (var conn = new SqlConnection(_configuration.Value))
            {
                const string query = @"SELECT * FROM Empresa ORDER BY VentasEmpresa DESC";

                empresas = await conn.QueryAsync<Empresa>(query, commandType: CommandType.Text);

            }
            return empresas;
        }

    }
}
